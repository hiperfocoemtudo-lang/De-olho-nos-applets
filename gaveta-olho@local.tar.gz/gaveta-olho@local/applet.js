const Applet = imports.ui.applet;
const Manager = imports.ui.appletManager;
const PopupMenu = imports.ui.popupMenu;
const Settings = imports.ui.settings;
const Main = imports.ui.main;
const Mainloop = imports.mainloop;
const DND = imports.ui.dnd;
const St = imports.gi.St;
const Clutter = imports.gi.Clutter;
const Cairo = imports.cairo;
const Tooltips = imports.ui.tooltips;

class DrawerMenu extends Applet.AppletPopupMenu {
    constructor(owner, orientation) { super(owner, orientation); this.owner = owner; }
    _calculatePosition() {
        if (!this.owner._ready || !this.owner.actor.get_stage()) return super._calculatePosition();
        let area = this.owner._area(), source = imports.gi.Cinnamon.util_get_transformed_allocation(this.owner.actor);
        let [, , width, height] = this.actor.get_preferred_size();
        let x = Math.max(area.x + 8, Math.min(source.x1 + (source.x2 - source.x1 - width) / 2, area.x + area.width - width - 8));
        let y = source.y2 + 8;
        if (y + height > area.y + area.height - 8) y = source.y1 - height - 8;
        return [Math.round(x), Math.round(Math.max(area.y + 8, y))];
    }
    open(animate = true) {
        if (this.isOpen || !this.owner._ready) return;
        this.owner._resize();
        if (DND.isDragging()) { this.owner.menuManager.shouldGrab = false; this.owner._openedDuringDrag = true; }
        super.open(animate && this.owner.animations);
        if (!DND.isDragging()) global.stage.set_key_focus(this.owner.root);
    }
    close(animate = true) {
        this.owner._closeChildren();
        super.close(animate && this.owner.animations && !this.owner._destroyed);
    }
}

class EyeDrawer extends Applet.Applet {
    constructor(metadata, orientation, panelHeight, instanceId) {
        super(orientation, panelHeight, instanceId);
        this._metadata = metadata;
        this._ready = false; this._destroyed = false;
        this._records = new Map(); this._pendingInside = new Set();
        this._eyeProgress = 0; this._timeline = null;
        this._syncIdle = this._poll = this._initIdle = 0;
        this.settings = new Settings.AppletSettings(this, metadata.uuid, instanceId);
        for (let [key, prop] of [['drawer-width','drawerWidth'],['drawer-height','drawerHeight'],['eye-size','eyeSize'],['animations','animations'],['horizontal-gap','horizontalGap'],['vertical-gap','verticalGap'],['color-mode','colorMode'],['stored-applets','storedApplets']]) {
            this.settings.bind(key, prop, () => this._scheduleSync());
        }
        this.eye = new St.DrawingArea({style_class:'applet-icon'});
        this.actor.add_actor(this.eye);
        this.eye.connect('repaint', () => this._drawEye());
        this.set_applet_tooltip('Gaveta de applets');
        this.menuManager = new PopupMenu.PopupMenuManager(this);
        this.menu = new DrawerMenu(this, orientation);
        this.menuManager.addMenu(this.menu);
        // Hosted applets keep their own popup managers. Let their popups receive input.
        let owner = this;
        this.menuManager._onKeyFocusChanged = function() {
            if (!owner._ownedPopups().length) PopupMenu.PopupMenuManager.prototype._onKeyFocusChanged.call(this);
        };
        this.menuManager._onEventCapture = function(actor, event) {
            if (owner._ownedPopups().length) return Clutter.EVENT_PROPAGATE;
            return PopupMenu.PopupMenuManager.prototype._onEventCapture.call(this, actor, event);
        };
        let section = new PopupMenu.PopupMenuSection(); this.menu.addMenuItem(section);
        this.root = new St.BoxLayout({vertical:true,style_class:'eye-drawer-root',can_focus:true});
        section.box.add_actor(this.root);
        this.editor = new St.BoxLayout({style_class:'eye-drawer-editor'});
        this.editor.add_actor(new St.Label({text:'Organizar applets',x_expand:true}));
        let done = new St.Button({label:'Concluir',style_class:'eye-drawer-done',reactive:true,can_focus:true});
        done.connect('clicked', () => global.settings.set_boolean('panel-edit-mode', false)); this.editor.add_actor(done);
        this.root.add_actor(this.editor);
        this.body = new St.BoxLayout({vertical:true,y_align:Clutter.ActorAlign.START,style_class:'eye-drawer-body'});
        this.scroll = new St.ScrollView({hscrollbar_policy:St.PolicyType.AUTOMATIC,vscrollbar_policy:St.PolicyType.AUTOMATIC});
        this.scroll.add_actor(this.body); this.root.add_actor(this.scroll);
        let drop = {handleDragOver:source=>this.handleDragOver(source),acceptDrop:source=>this.acceptDrop(source)};
        this.body._delegate = drop; this.scroll._delegate = drop; this.root._delegate = drop;
        this.root.connect('key-press-event',(actor,event)=>{
            if (event.get_key_symbol()===Clutter.KEY_Escape) { this.menu.close(); return Clutter.EVENT_STOP; }
            return Clutter.EVENT_PROPAGATE;
        });
        this.menu.connect('open-state-changed',(menu,open)=>this._animateEye(open ? 1 : 0));
        this.editItem = new PopupMenu.PopupSwitchMenuItem('Organizar applets',global.settings.get_boolean('panel-edit-mode'));
        this.editItem.connect('toggled',(item,state)=>{
            global.settings.set_boolean('panel-edit-mode',state);
            this._applet_context_menu.close(false);
            if(state) this.menu.open();
        });
        this._applet_context_menu.addMenuItem(this.editItem);
        let restore = new PopupMenu.PopupMenuItem('Devolver todos ao painel');
        restore.connect('activate',()=>this._returnAll()); this._applet_context_menu.addMenuItem(restore);
        this._editSignal = global.settings.connect('changed::panel-edit-mode',()=>{
            this.editItem.setToggleState(global.settings.get_boolean('panel-edit-mode'));
            this._scheduleSync();
        });
        this._enabledSignal = global.settings.connect('changed::enabled-applets',()=>this._scheduleSync());
        this._draggable.connect('drag-begin',()=>{this._eyeWasDragged=true;});
        this.actor.connect('button-press-event',(actor,event)=>{if(event.get_button()===1)this._eyeWasDragged=false;return Clutter.EVENT_PROPAGATE;});
        this.actor.connect('button-release-event',(actor,event)=>{
            if(event.get_button()===1 && global.settings.get_boolean('panel-edit-mode') && !this._eyeWasDragged) {this.menu.toggle();return Clutter.EVENT_STOP;}
            return Clutter.EVENT_PROPAGATE;
        });
    }
    _area() {
        let monitor = (this.actor.get_stage() ? Main.layoutManager.findMonitorForActor(this.actor) : null) || Main.layoutManager.primaryMonitor;
        return global.workspace_manager.get_active_workspace().get_work_area_for_monitor(monitor.index);
    }
    _ownedPopups() {
        if (!this.root) return [];
        let owned=[];
        for (let menu of global.menuStack || []) {
            let source=menu.sourceActor;
            if(menu===this.menu || !source || source.is_finalized())continue;
            if(this.root.contains(source) || owned.some(parent=>parent.actor.contains(source)))owned.push(menu);
        }
        return owned;
    }
    _closeChildren() { for(let menu of this._ownedPopups().reverse())menu.close(false); }
    _stopTimeline() {
        if(!this._timeline)return;
        this._timeline.stop(); this._timeline.disconnect(this._frameSignal); this._timeline.disconnect(this._endSignal); this._timeline=null;
    }
    _animateEye(target) {
        this._stopTimeline();
        if(this._destroyed || !this.animations) {this._eyeProgress=target;if(!this._destroyed)this.eye.queue_repaint();return;}
        let start=this._eyeProgress;
        let timeline=new Clutter.Timeline({duration:Math.max(60,Math.round(180*Math.abs(target-start)))});
        this._timeline=timeline;
        this._frameSignal=timeline.connect('new-frame',()=>{let t=timeline.get_progress();t=t*t*(3-2*t);this._eyeProgress=start+(target-start)*t;this.eye.queue_repaint();});
        this._endSignal=timeline.connect('completed',()=>{this._eyeProgress=target;this.eye.queue_repaint();this._stopTimeline();});
        timeline.start();
    }
    _drawEye() {
        let cr=this.eye.get_context(),[width,height]=this.eye.get_surface_size(),scale=Math.min(width,height)/20;
        let color=this.eye.get_theme_node().get_foreground_color(),t=this._eyeProgress,cx=width/2,cy=height/2;
        cr.setSourceRGBA(color.red/255,color.green/255,color.blue/255,color.alpha/255);
        cr.setLineWidth(1.5*scale);cr.setLineCap(Cairo.LineCap.ROUND);
        cr.moveTo(cx-8*scale,cy);
        cr.curveTo(cx-4*scale,cy+(2-7*t)*scale,cx+4*scale,cy+(2-7*t)*scale,cx+8*scale,cy);cr.stroke();
        if(t>0.01){cr.moveTo(cx-8*scale,cy);cr.curveTo(cx-4*scale,cy+5*t*scale,cx+4*scale,cy+5*t*scale,cx+8*scale,cy);cr.stroke();cr.arc(cx,cy,2.1*t*scale,0,Math.PI*2);cr.fill();}
        if(t<0.95){cr.setSourceRGBA(color.red/255,color.green/255,color.blue/255,(1-t)*color.alpha/255);for(let x of [-5,0,5]){cr.moveTo(cx+x*scale,cy+(x===0?1.5:1)*scale);cr.lineTo(cx+(x*1.15)*scale,cy+4*scale);cr.stroke();}}
        cr.$dispose();
    }
    _definition(entry) { return Manager.definitions.find(d=>d&&String(d.applet_id)===String(entry.id)&&d.uuid===entry.uuid); }
    _scheduleSync() {
        if(!this._ready || this._destroyed || this._syncIdle)return;
        this._syncIdle=Mainloop.timeout_add(150,()=>{this._syncIdle=0;this._sync();return false;});
    }
    _sync() {
        if(!this._ready || this._destroyed)return;
        for(let [id,record] of this._records){
            let entry=(this.storedApplets||[]).find(e=>String(e.id)===id),definition=entry&&this._definition(entry);
            if(!entry)this._dropRecord(id,true);
            else if(!definition || definition.applet!==record.applet)this._dropRecord(id,false);
            else if(record.applet.actor.get_parent()!==record.slot && !record.applet._dragging){
                let parent=record.applet.actor.get_parent();if(parent)parent.remove_child(record.applet.actor);
                record.slot.insert_child_at_index(record.applet.actor,0);record.applet._panelLocation=record.slot;this._layoutKey='';
            }
        }
        for(let entry of this.storedApplets||[]){
            let definition=this._definition(entry),applet=definition&&definition.applet,id=String(entry.id);
            if(!applet || applet===this || this._records.has(id))continue;
            this._adopt(entry,applet);
        }
        this._resize();this._reflow();
        if(this._openedDuringDrag && !DND.isDragging()){
            this._openedDuringDrag=false;this.menuManager.shouldGrab=true;
            if(this.menu.isOpen)this.menuManager._onMenuOpenState(this.menu,true);
        }
    }
    _adopt(entry,applet) {
        let id=String(entry.id),slot=new St.BoxLayout({style_class:'eye-drawer-slot',y_align:Clutter.ActorAlign.CENTER});
        let record={entry,applet,slot};this._records.set(id,record);this._layoutKey='';
        let parent=applet.actor.get_parent();if(parent)parent.remove_child(applet.actor);
        slot.add_actor(applet.actor);applet._panelLocation=slot;
        let back=new St.Button({label:'↥',style_class:'eye-drawer-return',reactive:true,can_focus:true});
        new Tooltips.Tooltip(back,'Devolver ao painel');back.connect('clicked',()=>this._returnOne(id));slot.add_actor(back);record.back=back;
        slot._delegate={handleDragOver:source=>this.handleDragOver(source),acceptDrop:source=>this.acceptDrop(source)};
        record.dragSignal=applet._draggable.connect('drag-end',(drag,time,success)=>{
            if(!success || this._pendingInside.has(id) || this._destroyed)return;
            Mainloop.idle_add(()=>{
                if(this._destroyed || !this._records.has(id))return false;
                // A native panel drop updates the applet's placement synchronously or on the next main-loop turn.
                if(applet._newPanelLocation && applet._newPanelLocation!==slot){
                    this.storedApplets=(this.storedApplets||[]).filter(e=>String(e.id)!==id);
                    this._dropRecord(id,true);this._reflow();
                }
                return false;
            });
        });
    }
    _restore(record) {
        let applet=record.applet;if(applet.actor.is_finalized())return;
        let definition=this._definition(record.entry);
        if(!definition || definition.applet!==applet)return;
        let panel=Main.panelManager.panels.find(p=>p&&p.panelId===definition.panelId);
        panel=panel||Main.panelManager.panels.find(Boolean);if(!panel)return;
        let zone=definition.location_label||record.entry.home.zone;
        let location=Manager.getLocation(panel,zone)||panel._rightBox;
        let parent=applet.actor.get_parent();if(parent!==location){if(parent)parent.remove_child(applet.actor);let before=location.get_children().find(c=>c._applet&&c._applet._order>definition.order);if(before)location.insert_child_below(applet.actor,before);else location.add_actor(applet.actor);}
        applet._panelLocation=location;
    }
    _dropRecord(id,restore) {
        let record=this._records.get(id);if(!record)return;
        this._records.delete(id);this._layoutKey='';record.applet._draggable.disconnect(record.dragSignal);
        if(restore)this._restore(record);
        if(record.applet.actor.get_parent()===record.slot)record.slot.remove_child(record.applet.actor);
        record.slot.destroy();
    }
    _returnOne(id) {
        this.storedApplets=(this.storedApplets||[]).filter(e=>String(e.id)!==id);
        this._dropRecord(id,true);this._reflow();
    }
    _returnAll() { for(let id of Array.from(this._records.keys()))this._dropRecord(id,true);this.storedApplets=[];this._reflow(); }
    _validSource(source) { return source instanceof Applet.Applet && source!==this && source._uuid!==this._metadata.uuid && source.actor.get_stage(); }
    handleDragOver(source) {
        if(!this._validSource(source))return DND.DragMotionResult.NO_DROP;
        if(!this.menu.isOpen)this.menu.open(false);
        return DND.DragMotionResult.MOVE_DROP;
    }
    acceptDrop(source) {
        if(!this._validSource(source))return false;
        Main.panelManager.resetPanelDND();
        let id=String(source.instance_id);this._pendingInside.add(id);
        Mainloop.idle_add(()=>{
            this._pendingInside.delete(id);if(this._destroyed)return false;
            let entries=(this.storedApplets||[]).slice();
            if(!entries.some(e=>String(e.id)===id)){
                let definition=Manager.definitions.find(d=>d&&d.applet===source);
                if(!definition)return false;
                entries.push({id,uuid:source._uuid,home:{panelId:definition.panelId,zone:definition.location_label,order:definition.order}});
                this.storedApplets=entries;
            }
            source._newPanelLocation=null;
            this._sync();return false;
        });
        return true;
    }
    _resize() {
        if(!this._ready || !this.actor.get_stage())return;
        let scale=global.ui_scale||1,area=this._area(),editing=global.settings.get_boolean('panel-edit-mode');
        if(this.eye.width!==this.eyeSize*scale){this.eye.set_size(this.eyeSize*scale,this.eyeSize*scale);this.eye.queue_repaint();}
        this._fitWidth(this._naturalWidths||[]);
        this.editor.visible=editing;this.editor.set_height(40*scale);
        this.scroll.set_height(Math.max(50,Math.min(this.drawerHeight,area.height/scale-30)-24-(editing?40:0))*scale);
        if(this._menuColorKey!==this.colorMode){
            let light=this.colorMode==='light';
            this.root.set_style_class_name('eye-drawer-root'+(light?' eye-drawer-light':''));
            this.menu.box.set_style('padding: 0; background-color: '+(light?'#f7f8fa':'#20232b')+'; color: '+(light?'#252630':'#eef0f6')+'; background-image: none; border-image: none; border: 1px solid '+(light?'#d4d8e1':'#454b59')+'; border-radius: 14px; box-shadow: 0 6px 20px rgba(0,0,0,0.28);');
            this._menuColorKey=this.colorMode;
        }
        if(this._bodyGap!==this.verticalGap){this.body.set_style('spacing: '+this.verticalGap+'px;');this._bodyGap=this.verticalGap;}
    }
    _fitWidth(widths) {
        let scale=global.ui_scale||1,area=this._area();
        // Leave room for padding and a vertical scrollbar when the drawer has many rows.
        let bar=this.scroll.get_vscroll_bar();
        this._scrollbarReserve=bar.get_stage()?Math.ceil(bar.get_preferred_width(-1)[1]):18*scale;
        let widest=widths.length?Math.max(...widths):0;
        let desired=Math.max(this.drawerWidth*scale,widest+24*scale+this._scrollbarReserve+2*scale);
        let limit=Math.max(120*scale,area.width-24*scale);
        let width=Math.min(desired,limit);
        if(Math.abs(this.root.width-width)>0.1)this.root.set_width(width);
    }
    _reflow() {
        if(!this._ready || this._destroyed)return;
        let records=(this.storedApplets||[]).map(e=>this._records.get(String(e.id))).filter(Boolean);
        let editing=global.settings.get_boolean('panel-edit-mode'),scale=global.ui_scale||1;
        let staging=null;
        let widths=records.map(record=>{
            record.back.visible=editing;
            // A newly stored applet must join the scene before requesting its natural size.
            if(!record.slot.get_stage()){
                if(!staging){staging=new St.BoxLayout();this.body.add_actor(staging);}
                staging.add_actor(record.slot);
            }
            return Math.ceil(record.slot.get_preferred_width(-1)[1]);
        });
        this._naturalWidths=widths;this._fitWidth(widths);
        let key=JSON.stringify([(this.storedApplets||[]).map(e=>String(e.id)),this._records.size,widths,this.root.width,this.horizontalGap,this.verticalGap,editing]);
        if(key===this._layoutKey)return;this._layoutKey=key;
        for(let record of this._records.values()){let p=record.slot.get_parent();if(p)p.remove_child(record.slot);}
        this.body.destroy_all_children();
        if(!records.length){let hint=new St.Label({text:'Arraste applets para cá.\nClique direito no olho → Organizar applets.',style_class:'eye-drawer-hint'});hint.clutter_text.set_line_wrap(true);this.body.add_actor(hint);return;}
        let max=this.root.width-24*scale-this._scrollbarReserve,row=null,used=0;
        for(let i=0;i<records.length;i++){
            let record=records[i],width=widths[i];
            if(!row || (used>0 && used+this.horizontalGap*scale+width>max)){
                row=new St.BoxLayout({style_class:'eye-drawer-row',style:'spacing: '+this.horizontalGap+'px;'});this.body.add_actor(row);used=0;
            }
            row.add_actor(record.slot);used+=(used>0?this.horizontalGap*scale:0)+width;
        }
    }
    on_applet_added_to_panel_internal(userEnabled) { super.on_applet_added_to_panel_internal(false); }
    on_applet_added_to_panel() {
        if(this._ready || this._initIdle || this._destroyed)return;
        this._initIdle=Mainloop.idle_add(()=>{if(this._destroyed){this._initIdle=0;return false;}if(!this.actor.get_stage())return true;this._initIdle=0;this._ready=true;this._sync();this._poll=Mainloop.timeout_add_seconds(1,()=>{this._sync();return true;});return false;});
    }
    on_applet_clicked() { if(this._ready)this.menu.toggle(); }
    on_applet_removed_from_panel() {
        this._destroyed=true;this._ready=false;this._stopTimeline();this.menu.close(false);
        for(let id of [this._initIdle,this._syncIdle,this._poll])if(id)Mainloop.source_remove(id);
        global.settings.disconnect(this._editSignal);global.settings.disconnect(this._enabledSignal);
        for(let id of Array.from(this._records.keys()))this._dropRecord(id,true);
        this.settings.finalize();this.menu.destroy();
    }
}
function main(metadata,orientation,panelHeight,instanceId){return new EyeDrawer(metadata,orientation,panelHeight,instanceId);}
